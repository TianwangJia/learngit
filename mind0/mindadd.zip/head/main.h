#ifndef _MAIN_H_
#define _MAIN_H_
#include "welcome.h"
#include "Signup.h"
#include "Log.h"
#include "ResetKey.h"
#include "Help.h"

void main(void);

#endif