#ifndef _COMMON_H_
#define _COMMON_H_
#include <graphics.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <bios.h>
#include"hz.h"
#include <dos.h>
#include <time.h>
#include "MOUSE.h"
#include "data.h"

#include "Boxa.h"
#include "Boxadl.h"
#include "Boxdate.h"
#include "Boxfb.h"
#include "Boxtr.h"
#include "Edidate.h"
#include "Edit.h"
#include "Editfb.h"
#include "EditT.h"
#include "Edittr.h"
#include "EnterT.h"
#include "Help.h"
#include "newa.h"
#include "Opena.h"
#include "Operate.h"
#include "OperateT.h"
#endif