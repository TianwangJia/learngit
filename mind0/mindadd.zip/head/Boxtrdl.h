#ifndef _BOXTRDL_H_
#define _BOXTRDL_H_

void deletebox_tr(MINDBOX (*editp)[VERTREE], int ho, int ve);

#endif // !_BOXTRDL_H_