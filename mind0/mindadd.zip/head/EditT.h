#ifndef _EDIT_T_H_
#define _EDIR_T_H_

void edit_mind(int x, int y, MINPUT *message,MINDBOX*mind, int color);

int judge_time(DATEHAPPEN time);

void edit_yugu(int x, int y, MINPUT *info, FISHBONE *bone, int color);

int rank_time(DATEINFO *timeline, DATEHAPPEN time);

#endif // !_EDIT_T_H
