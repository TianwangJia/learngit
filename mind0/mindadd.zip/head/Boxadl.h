#ifndef _BOXADL_H_
#define _BOXADL_H_

void deletebox(MINDBOX (*editp)[16], int ho, int ve);

#endif // !_BOXADL_H_